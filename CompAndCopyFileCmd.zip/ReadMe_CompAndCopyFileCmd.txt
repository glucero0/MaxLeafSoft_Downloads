CompAndCopyFileCmd 
MaxLeafSoft

Version 1.1.2.0
Copyright (C) 2020 MaxLeafSoft
https://github.com/glucero0/MaxLeafSoft_Downloads
https://www.variousandsundrytechtopics.com/

CompAndCopyFileCmd is licensed under Creative Commons Licensing, Attribution-NoDerivs (CC BY-ND):

https://creativecommons.org/licenses/by-nd/4.0/

USAGE:

--------------------
Compare Files 
--------------------

CompAndCopyFileCmd.exe [Source Filename] [Destination Filename] [/D | /V] [/R {optional}]

[Source Filename is the file you want to copy if it is newer than the destination file]
[Destination Filename is the file you want to compare the source file to]
[Pass in /D to compare the file's modified date and times, or /V to compare the file's version info]
[For EXEs, optionally pass in /R, which starts the app after comparing and copying the file. With RunDestFile, the app will run regardless of whether it's ultimately copied or not]

------------------------
Compare Folders 
------------------------

CompAndCopyFileCmd.exe [Source Folder] [Destination Folder] [/R | /N]

[Source Folder is the folder to compare to the destination folder and copy from]
[Destination Folder is the folder to compare and copy to ]
[To recursively compare folders, pass /R as third parameter, or to only compare and copy files from Source Folder, pass /N]

[Comparison method is always based on modified date/time. Source files that are newer are copied from the source folder to the destination]

[NOTE: Command-line parameters with spaces must be surrounded with quote marks]

-----------------
Display Help 
-----------------

CompAndCopyFileCmd.exe [/H] displays this help info

CHANGE LOG:

Version 1.1.2.0 - 

-Initial public release
